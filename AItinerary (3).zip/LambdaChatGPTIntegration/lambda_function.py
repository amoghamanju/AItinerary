import json
import openai
import os
import logging

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # Log the received event
    if(event['httpMethod']=='OPTIONS'):
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*'
            }
        }
        
    logger.info(f"Received event: {event}")

    # Extract the prompt from the HTTP request
    try:
        body = json.loads(event['body'])
        logger.info(f"Body: {body}")
        prompt = body
    except KeyError:
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*'
            },
            'body': json.dumps({'message': 'No prompt provided'})
        }

    # Get the response from ChatGPT
    response = get_chatgpt_response(prompt)
    logger.info(f"Response: {response}")
    # Assuming the response object has a 'choices' attribute which is a list
    # and each choice has a 'message' attribute which is a ChatCompletionMessage object
    if response.choices and hasattr(response.choices[0], 'message') and hasattr(response.choices[0].message, 'content'):
        message_content = response.choices[0].message.content
    else:
        message_content = "Response format is unexpected"

    # Return the response
    return {
        'statusCode': 200,
         'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*'
            },
        'body': json.dumps({'response': message_content})
    }


def get_chatgpt_response(prompt):
    # Instantiate a new OpenAI client
    # client = openai.OpenAI(api_key=os.environ.get('OPENAI_API_KEY'))
    client = openai.OpenAI(api_key="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")

    # Create a chat completion
    completion = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ]
    )
    return completion

if __name__ == "__main__":
    # Local testing
    test_prompt = "Who won the last world cup?"
    print(lambda_handler({"body": json.dumps({"prompt": test_prompt})}, None))
